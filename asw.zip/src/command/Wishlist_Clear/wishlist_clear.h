#ifndef WSHC
#define WSHC
#include "../../ADT/User_Barang/user.h"
#include "../../ADT/User_Barang/barang.h"
#include "../../ADT/Mesin_Kata/mesinkata.h"
#include "../../ADT/LinkedList/linkedlist.h"


void WishlistClear(UserList *userArray, char *userName);


#endif