#ifndef WISHLISTSWAP_H
#define WISHLISTSWAP_H

#include "../../ADT/boolean.h"
#include "../../ADT/LinkedList/linkedlist.h"

void WishlistSwap(Wishlist *wishlist, int i, int j);

#endif
