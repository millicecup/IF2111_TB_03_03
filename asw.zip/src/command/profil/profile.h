#ifndef PROFILE_H
#define PROFILE_H
#include "../../ADT/User_Barang/user.h"
#include "../../ADT/Mesin_Kata/mesinkata.h"
#include <stdio.h>
void profile(UserList *userArray);
#endif