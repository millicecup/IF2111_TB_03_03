#ifndef TEBAK_H
#define TEBAK_H
#include "../../../ADT/User_Barang/user.h"

void tebakangka(UserList *userList);

#endif
