#ifndef WISHLISTSWAP_H
#define WISHLISTSWAP_H

#include "../../ADT/boolean.h"
#include "../../ADT/LinkedList/linkedlist.h"
#include "../../ADT/User_Barang/user.h"

void WishlistSwap(UserList *userlist, int i, int j);

#endif
