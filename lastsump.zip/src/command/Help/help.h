#ifndef HELP_H
#define HELP_H

#include <stdio.h>
#include "../../ADT/User_Barang/menu.h"


void help(MenuState *current_menu);
void update_menu(MenuState *current_menu, MenuState menu_updated);

#endif // HELP_H
