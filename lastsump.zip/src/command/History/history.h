#ifndef HISTORY_H
#define HISTORY_H

#include "../../ADT/Stack/stack.h"

void DisplayHistory(int N, UserList *userList);

#endif