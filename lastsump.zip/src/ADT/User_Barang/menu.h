#ifndef MENU_H
#define MENU_H

typedef enum {
    menuforwelcome,
    menuforlogin,
    menuutama,
    menustore,
    menuwork,
    menuworkchallenge,
    menucart,
    menuwishlist
} MenuState;

#endif // MENU_H