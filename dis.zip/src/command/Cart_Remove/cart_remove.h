#ifndef CART_REMOVE_H
#define CART_REMOVE_H

#include "../../ADT/boolean.h"
#include "../../ADT/SetMap/setmap.h"
#include "../../ADT/User_Barang/barang.h"
#include "../../ADT/Mesin_Kata/mesinkata.h"
// #include "../Store_List/Store_List.h"

void RemoveCart(Keranjang *k, char *item, int qty);

#endif 