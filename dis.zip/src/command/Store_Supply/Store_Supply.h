#include <stdio.h>
#include <stdlib.h>

#include "../../ADT/boolean.h"
#include "../../ADT/User_Barang/barang.h"
#include "../../ADT/Mesin_Kata/mesinkata.h"
#include "../../ADT/queue/queue.h"
#include "../Store_List/Store_List.h"
#include "../Store_Request/Store_Request.h"

void storeSupply(BarangList *store, Queue *request);