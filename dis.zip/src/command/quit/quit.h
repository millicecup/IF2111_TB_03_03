#ifndef QUIT_H
#define QUIT_H

#include "../../ADT/User_Barang/user.h" 
#include "../../ADT/boolean.h"
#include "../../command/save/save.h"

// Deklarasi fungsi quit
void quit(boolean *issave, UserList list);

#endif