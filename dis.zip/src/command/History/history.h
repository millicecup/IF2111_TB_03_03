#ifndef HISTORY_H
#define HISTORY_H

#include "../../ADT/Stack/stack.h"

void DisplayHistory(History H, int N);

#endif