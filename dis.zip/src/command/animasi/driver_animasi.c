#include <stdio.h>
#include <stdlib.h>
#include "animasi.h"

/*
gcc driver_animasi.c animasi.c 
*/
int main()
{
    animasiMainMenu();
    printWorkMenu();
    perrystop();
    return 0;
}

