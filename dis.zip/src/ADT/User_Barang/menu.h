#ifndef MENU_H
#define MENU_H

typedef enum {
    menuforwelcome,
    menuforlogin,
    menuutama,
    menustore,
    menuwork,
    menuworkchallenge,
} MenuState;

#endif // MENU_H